package com.epam.cdp.byta2015.module3.lecture2.tourist.datawriters;

import com.epam.cdp.byta2015.module3.lecture2.tourist.model.Offer;

public abstract class AbstractWriter {
	
	public abstract void writeInfo();

}
