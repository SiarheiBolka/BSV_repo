package com.epam.cdp.byta2015.tourist.model;

import java.util.List;

public class Excursion extends BaseTour {
	
	protected List<String> destination;
	protected String country;
	
	public Excursion(Integer id, String typeDesc, String food, String transport, Integer duration, Double price, String country, List<String> destination) {
		super(id, typeDesc, food, transport, duration, price);
		this.country = country;
		this.destination = destination;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public List<String> getDestination() {
		return destination;
	}

	public void setDestination(List<String> destination) {
		this.destination = destination;
	}
	
	public String getInfo(){
		return "Id: " + this.id + ", Type: " + this.typeDesc + ", Duration: " + this.duration  + ", Price: " + this.price + ", Country: " + this.country + "; Destinations: " + this.destination;
	}

}
