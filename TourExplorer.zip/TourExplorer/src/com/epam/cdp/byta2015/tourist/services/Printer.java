package com.epam.cdp.byta2015.tourist.services;

import com.epam.cdp.byta2015.tourist.model.BaseTour;

import java.util.List;

/**
 * Created by Siarhei_Bolka on 4/8/2015.
 */
public interface Printer {
    public void print(List<BaseTour> list);
}
