package com.epam.cdp.byta2015.tourist.Datawriters;

/**
 * Created by Siarhei_Bolka on 4/13/2015.
 */
public class DatabaseWriter implements Writer{
}
